def Galimaties(fIn,fOut):
	Tcodi = {'a':'apa','A':'ApA','e':'epe','E':'EpE','i':'ipi','I':'IpI','o':'opo','O':'OpO','u':'upu','U':'UpU'}
	if isinstance(fIn,str) and isinstance(fOut,str):
		try:
			r = open(fIn,'r')
			text = r.read()
			r.close()
		except:
			text =''
			print ' Arxiu ' + fIn + ' inexistent'

		w = open(fOut,'w')
		for c in text:
			w.write(Tcodi.get(c,c))
		w.close()
	else:
		print ' Nom arxiu(s) input i/o output incorrectes'

			
import string
Galimaties('input.txt','output.txt')		


