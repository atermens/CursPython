def bolets_toxics():
	try:
		r = open('Bolets.txt','r')
		w = open('toxic.txt,'w')
		while 1:
			linia = r.readline()
			if linia != '':
				if 'TOXIC' in linia:
					w.write(linia)
			else:
				break
		r.close()
		w.close()
			
	except:
		print ' Arxiu <Bolets.txt> no existeix'

def CreaFitxersNotes():
	iNumEstudiants = int(raw_input(' Entra el num total estudiants: '))

	f1 = open('L1.txt','w')
	f2 = open('L2.txt','w')
	f3 = open('L3.txt','w')
	f4 = open('L4.txt','w')
	f5 = open('L5.txt','w')

	iEstudiant = 0
	while iEstudiant < iNumEstudiants:
		sDNI = raw_input(' Entrar DNI: ')
		if len(sDNI) == 8:
			lNotes = string.split(raw_input(' Entrar 5 notes separades per espais: '))
			if len(lNotes) == 5:
				pickle.dump(sDNI,f1)
				pickle.dump(lNotes[0],f1)
				pickle.dump(sDNI,f2)
				pickle.dump(lNotes[1],f2)
				pickle.dump(sDNI,f3)
				pickle.dump(lNotes[2],f3)
				pickle.dump(sDNI,f4)
				pickle.dump(lNotes[3],f4)
				pickle.dump(sDNI,f5)
				pickle.dump(lNotes[4],f5)
				iEstudiant += 1
			else:
				print ' Error introduint les notes...'
				break
		else:
			print ' Error DNI invalid'
			break

	f1.close()
	f2.close()
	f3.close()
	f4.close()
	f5.close()
	return iNumEstudiants




def CreaNotaFinal(iNumEstudiants):
	dni = []
	nota =()
	iNota = 1
	while iNota < 6:
		FileName = 'L'+iNota+'.txt'
		f = open(FileName,'r')
		iEstudiant = 0
		while iEstudiant < iNumEstudiants:
			dni = pickle.load(f)
			nota = pickle.load(f)
			kDNI.append(dni)
			dades[dni] = nota
		f.close()
	w = open('LF.txt','w')
	for k in kDNI:
		nota = 0.0
		for e in dades
	w.close()
	



La segona funció, a partir dels fitxers creats anteriorment, en crearà un de nou "LF.txt" on per cada estudiant, escriurà una linia amb el seu DNI 
i la nota mitjana final separats per una tabulació. Aquest si que ha de crear-se forçant que siguin strings.


import string
import pickle

bolets_toxics()
