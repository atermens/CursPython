
def arrel(n):
	x = float(n)
	x1 = float((n+1)/2.0)
	while abs(x1-x)>0.0001:
		x = x1
		x1 = float((x+(n/x))/2.0)
	return x1



def posneg1(ln): 
	c = 0
	for el in ln:
		if el < 0:
			c -= 1
		else:
			c += 1
	
	if  c == len(ln):
		return 'pos'
	elif c == -len(ln):
		return 'neg'
	else:
		return 'posneg'



def posneg2(lini): 
	lPos = [] 
	lNeg = [] 
	for el in lini:
		if el < 0:
			lNeg.append(el)
		else:
			lPos.append(el)

	lNeg.sort()
	lPos.sort()

	return [lNeg,lPos]



def posneg2bis(lini):
	lPos = lini[:]
	lNeg = lini[:]	

	iP = 0
	iN = 0
	for el in lini:
		if el < 0:
			del lPos[iP]
			iN += 1
		else:
			del lNeg[iN]
			iP += 1

	lNeg.sort()
	lPos.sort()

	return [lNeg,lPos]


def min_x_max(llista):
	lWrk = llista[:]
	lWrk[llista.index(min(llista))] = max(llista)
	lWrk[llista.index(max(llista))] = min(llista)
	return lWrk
			
		
		
def GeneraDiccionari(text):
	Diccionari = {}
	for c in text:
		Diccionari[c] = Diccionari.get(c,0) + 1
	sorted(Diccionari)
	return Diccionari


def Codi1(taula,text):
	traduccio = ''
	for c in text:
		traduccio = traduccio + taula.get(c,'?')
	return traduccio



def Codi2(taula,text):
	for key in taula.keys():
		text = text.replace(key,taula.get(key,'?'))
	return text
	
	
def InvTaula(taula):
	Out = {}
	for key in taula.keys():
		Out[taula.get(key)] = key
	sorted(Out)
	return Out
	


import string
import math

T = {'h':'a', 'o':'d', 'l':'e', 'a':'u'}
s = 'hola'
print s,' >>> ',Codi1(T,s),' ',Codi2(T,s)
print InvTaula(T)

	

