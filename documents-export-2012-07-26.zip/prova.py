def Itera(sText):
	iN = int(raw_input('Introdueix Num Iteracions: '))
	iIndex = 0
	while iIndex <iN:
		print sText
		iIndex += 1
		
	

