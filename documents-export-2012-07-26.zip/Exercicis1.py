def GeneraDiccionari():
	d = {'poma': 'manzana', 'albercoc': 'albaricoque', 'taronja': 'naranja', 'maduixa': 'fresa'}
	return d


def ConsultaDiccionari(d,w):
	return d.get(w,' ??? (no es troba al diccionari) ')


def AfegeixParaula(d,wCAT,wES):
	d[wCAT] = wES
	return


def EliminaParaula(d,wCAT):
	wES = d[wCAT]
	if d.has_key(wCAT):
		del d[wCAT]
		print ' Paraula ',wCAT,' >>> ',wES,' eliminada del diccionari'
	else:
		print ' No podem esborrar un element que no existeix'
	return


def GestionaDiccionari():
	"""
	Gestiona Diccionari @ 2012
	Opcions suportades:
	1. Generar diccionari catala-castella
	2. Consulta paraula
	3. Llistat de paraules a consultar
	4. Afegir paraula al diccionari
	5. Eliminar paraula del diccionari
	Qualsevol altra opcio, surt del diccionari
	"""
	iOption = int(raw_input('\n\n -------------------------------\n   GestionaDiccionari @ 2012\n -------------------------------\n\n Entrar opcio :\n\n 1. Generar diccionari catala-castella\n 2. Consultar alguna paraula\n 3. Veure quines paraules pot consultar\n 4. Afegir alguna nova paraula\n 5. Eliminar alguna paraula\n    Qualsevol altra opcio per acabar\n\n'))
	while 1:
		if iOption == 1:
			Dcat2es = GeneraDiccionari()
			print ' Diccionari catala-castella generat.'
		elif iOption == 2:
			if len(Dcat2es) > 0:
				wcat = raw_input(' Paraula a consultar: ')
				wes = ConsultaDiccionari(Dcat2es,wcat)
				print ' La traduccio de ',wcat,' >>> ',wes
			else:
				print ' El diccionari no existeix. Premeu abans opcio 1'
		elif iOption == 3:
			print ' Llistat de paraules a consultar: ',Dcat2es.keys()
		elif iOption == 4:
			wcat = raw_input(' Paraula en catala a afegir: ')
			wes = raw_input (' Entra la seva traduccio al castella: ')
			AfegeixParaula(Dcat2es,wcat,wes)
			print ' Paraula ',wcat,' >>> ',wes,' afegida al diccionari'
		elif iOption == 5:
			wcat = raw_input(' Paraula a eliminar: ')
			EliminaParaula(Dcat2es,wcat)
		else:
			print ' Sortim...'
			break
		iOption = int(raw_input('\n Entreu una altra opcio:\n'))
	return


GestionaDiccionari()



